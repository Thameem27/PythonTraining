from db import db

class UserDet(db.Model):
    __tablename__ = "user_det"
    User_id = db.Column(db.Integer, primary_key=True)
    Username = db.Column(db.String(100), unique=True, nullable=False)
    Password = db.Column(db.String(100), unique=True, nullable=False)
    Email = db.Column(db.String(140), unique=True, nullable=False)
    
    def __init__(self, Username, Password, Email):
        self.Username = Username
        self.Password = Password
        self.Email = Email
    
    def __repr__(self):
        return '<User %r is Created>' % self.Username
