from flask import Flask, request, jsonify
from flask_restful import Api, Resource
from flask_sqlalchemy import SQLAlchemy,BaseQuery
from sqlalchemy import create_engine, exc, ForeignKey
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import scoped_session, sessionmaker
from flask_marshmallow import Marshmallow
from marshmallow_sqlalchemy import SQLAlchemySchema, auto_field
Base = declarative_base()
app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///Bank_Project.sqlite3'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
api = Api(app)
Bank_Project = SQLAlchemy(app)
ma = Marshmallow(app)
class Customer(Base):
    __tablename__="Customer"
    CUSTOMER_ID = Bank_Project.Column(Bank_Project.Integer, primary_key=True)
    CUSTOMER_NAME = Bank_Project.Column(Bank_Project.String(100), nullable=False)
    USERNAME = Bank_Project.Column(Bank_Project.String(30), nullable=False)
    PASSWORD = Bank_Project.Column(Bank_Project.String(1000), nullable=False)
    COMMUNICATION_ADDRESS = Bank_Project.Column(Bank_Project.String(200), nullable=False)
    PERMANENT_ADDRESS = Bank_Project.Column(Bank_Project.String(200), nullable=False)
    COUNTRY = Bank_Project.Column(Bank_Project.String(20), nullable=False)
    EMAIL_ADDRESS = Bank_Project.Column(Bank_Project.String(50), nullable=False)
    PAN = Bank_Project.Column(Bank_Project.String(20), nullable=False)
    CONTACT_NO= Bank_Project.Column(Bank_Project.Integer, nullable=False)
    DOB = Bank_Project.Column(Bank_Project.String(20), nullable=False)
    def __repr__(self):
        return '<User %r is now Created with an Account Type %r >' % (self.USERNAME, self.account_type)
class Account(Base):
    __tablename__="Account"
    ACCOUNT_ID = Bank_Project.Column(Bank_Project.Integer, primary_key=True)
    CUSTOMER_NAME = Bank_Project.Column(Bank_Project.String(10), nullable=False)
    CUST_ID = Bank_Project.Column(Bank_Project.Integer, ForeignKey('Customer.CUSTOMER_ID'))
    ACCOUNT_TYPE = Bank_Project.Column(Bank_Project.String(20), nullable=False)
    CURRENT_BALANCE= Bank_Project.Column(Bank_Project.Integer, nullable=False)
    LAST_WITHDRAWL_AMOUNT = Bank_Project.Column(Bank_Project.Integer, nullable=False)
    STATUS = Bank_Project.Column(Bank_Project.String(20), nullable=False)
    def __repr__(self):
        return '<Account for %r is now Created with an Account Type %r >' % (self.USERNAME, self.account_type)
# Set up database
engine = create_engine('sqlite:///Bank_Project.sqlite3',connect_args={'check_same_thread': False},echo=True)
db = scoped_session(sessionmaker(bind=engine))
Base.metadata.bind = engine
Base.metadata.create_all(engine)
class CustomerSchema(ma.SQLAlchemyAutoSchema):
    class Meta:
        model = Customer
class ViewCustomerSchema(ma.SQLAlchemySchema):
    class Meta:
        model = Customer
    USERNAME=auto_field()
    COMMUNICATION_ADDRESS=auto_field()
    PAN=auto_field()
class AccountSchema(ma.SQLAlchemyAutoSchema):
    class Meta:
        model = Account
customer_schema = CustomerSchema()
customers_schema = CustomerSchema(many=True)
viewcustomer_schema = ViewCustomerSchema()
class ViewCustomer(Resource):
    def get(self,customername):
        Cust = db.execute("SELECT * from Customer where USERNAME = :c",{"c": customername}).fetchone()
        #Cust = Customer.query.filter_by(USERNAME=customername).first_or_404(description='No Customer Exists with this Username {}. Kindly Re-check'.format(customername))
        if Cust is None:
            return jsonify({"Message":f"Customer {customername} doesn't exist in the Bank Database"}) 
        return viewcustomer_schema.dump(Cust)
        # return customers_schema.dump(cust)
class AddCustomer(Resource):
    def get(self):
        #cust = Customer.query.all()
        #cust = db.session.query(Customer).query.all()
        data = db.execute("SELECT * from Customer").fetchall()
        return customers_schema.dump(data)
    def post(self):
        result = db.execute("SELECT * from Customer WHERE USERNAME = :c", {"c": request.json['USERNAME']}).fetchone()
        if result is None :
                # result = db.query(Customer).count()
                new_cust = Customer(
                    CUSTOMER_NAME = request.json['NAME'],
                    USERNAME = request.json['USERNAME'],
                    PASSWORD = request.json['PASSWORD'],
                    COMMUNICATION_ADDRESS = request.json['COMMUNICATION_ADDRESS'],
                    PERMANENT_ADDRESS = request.json['PERMANENT_ADDRESS'],
                    COUNTRY = request.json['COUNTRY'],
                    EMAIL_ADDRESS = request.json['EMAIL_ADDRESS'],
                    PAN = request.json['PAN'],
                    CONTACT_NO = request.json['CONTACT_NO'],
                    DOB = request.json['DOB']
                )
                Bank_Project.session.add(new_cust)
                Bank_Project.session.commit()
                return customer_schema.dump(new_cust), 201
        return f"User {request.json['USERNAME']} already Exists in the Table."
class AddAccount(Resource):  
    def post(self):
        cust_id = db.execute("SELECT CUSTOMER_ID from Customer WHERE USERNAME = :c", {"c": request.json['USERNAME']}).fetchone()
        result = db.execute("SELECT * from Account WHERE CUSTOMER_NAME = :c and ACCOUNT_TYPE = :t", {"c": request.json['USERNAME'], "t": request.json['ACCOUNT_TYPE']}).fetchone()
        if result is None :
                # result = db.query(Customer).count()
                new_acct = Account(
                    CUSTOMER_NAME = request.json['CUSTOMER_NAME'],
                    CUST_ID = cust_id,
                    ACCOUNT_TYPE = request.json['ACCOUNT_TYPE'],
                    CURRENT_BALANCE = request.json['CURRENT_BALANCE'],
                    LAST_WITHDRAWL_AMOUNT = request.json['LAST_WITHDRAWL_AMOUNT'],
                    STATUS = request.json['STATUS']
                )
                Bank_Project.session.add(new_acct)
                Bank_Project.session.commit()
                return customer_schema.dump(new_acct), 201
        return f"Account for User {request.json['USERNAME']} with Account Type {request.json['ACCOUNT_TYPE']} already Exists in the Table."
api.add_resource(AddCustomer,'/addcustomer')
api.add_resource(ViewCustomer,'/viewcustomer/<customername>')
api.add_resource(AddAccount,'/addaccount')