-- SQLite
select * from Developer
