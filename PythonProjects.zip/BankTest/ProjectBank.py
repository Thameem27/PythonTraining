from flask import Flask, request, jsonify
from flask_restful import Api, Resource
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import create_engine, exc
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import scoped_session, sessionmaker
from flask_marshmallow import Marshmallow
from marshmallow_sqlalchemy import SQLAlchemySchema, auto_field
Base = declarative_base()
app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///AppDB.sqlite3'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
api = Api(app)
AppDB = SQLAlchemy(app)
ma = Marshmallow(app)
# Set up database
engine = create_engine('sqlite:///AppDB.sqlite3',connect_args={'check_same_thread': False},echo=True)
Base.metadata.bind = engine
db = scoped_session(sessionmaker(bind=engine))
class Customer(AppDB.Model):
    CUSTOMER_ID = AppDB.Column(AppDB.Integer, primary_key=True)
    CUSTOMER_NAME = AppDB.Column(AppDB.String(100), nullable=False)
    USERNAME = AppDB.Column(AppDB.String(30), nullable=False)
    PASSWORD = AppDB.Column(AppDB.String(20), nullable=False)
    COMMUNICATION_ADDRESS = AppDB.Column(AppDB.String(100), nullable=False)
    PERMANENT_ADDRESS = AppDB.Column(AppDB.String(100), nullable=False)
    COUNTRY = AppDB.Column(AppDB.String(20), nullable=False)
    EMAIL_ADDRESS = AppDB.Column(AppDB.String(50), nullable=False)
    PAN = AppDB.Column(AppDB.String(20), nullable=False)
    CONTACT_NO= AppDB.Column(AppDB.Integer, nullable=False)
    DOB = AppDB.Column(AppDB.String(20), nullable=False)
    ACCOUNT_TYPE = AppDB.Column(AppDB.String(20), nullable=False)
    def __repr__(self):
        return '<User %r is now Created with an Account Type %r >' % (self.USERNAME, self.ACCOUNT_TYPE)
class CustomerSchema(ma.SQLAlchemyAutoSchema):
    class Meta:
        model = Customer
class ViewCustomerSchema(ma.SQLAlchemySchema):
    class Meta:
        model = Customer
    USERNAME=auto_field()
    ADDRESS=auto_field()
    PAN=auto_field()
    ACCOUNT_TYPE=auto_field()
customer_schema = CustomerSchema()
customers_schema = CustomerSchema(many=True)
viewcustomer_schema = ViewCustomerSchema()
class UpdateAccountDetails(Resource):  
    def put(self, customer_id):
        cust = Customer.query.get_or_404(customer_id)
        if 'CUSTOMER_NAME' in request.json:
            cust.CUSTOMER_NAME = request.json['CUSTOMER_NAME']
        if 'USERNAME' in request.json:
            cust.USERNAME = request.json['username']
        # if 'PASSWORD' in request.json:
           # cust.password = request.json['password']
        if 'COMMUNICATION_ADDRESS' in request.json:
           cust.COMMUNICATION_ADDRESS = request.json['communication_address']
        if 'PERMANENT_ADDRESS' in request.json:
           cust.PERMANENT_ADDRESS = request.json['permanent_address']
        if 'COUNTRY' in request.json:
           cust.COUNTRY = request.json['country']
        if 'EMAIL_ADDRESS' in request.json:
           cust.EMAIL_ADDRESS = request.json['email_address']   
        if 'PAN' in request.json:
           cust.PAN = request.json['pan']
        if 'CONTACT_NO' in request.json:
           cust.CONTACT_NO = request.json['contact_no']
        if 'DOB' in request.json:
           cust.DOB = request.json['dob']
        # if 'ACCOUNT_TYPE' in request.json:
           # cust.ACCOUNT_TYPE = request.json['account_type']         
        db.session.commit()
        return customer_schema.dump(cust)
    def delete(self, customer_id):
        cust = Customer.query.get_or_404(customer_id)
        db.session.delete(cust)
        db.session.commit()
        return 'Customer Deleted From the Database', 204
class ViewCustomer(Resource):
    def get(self,custid):
        Cust = Customer.query.filter_by(CUSTOMER_ID=custid).first_or_404(description='No Customer Exists with this User ID {}. Kindly Re-check'.format(custid))
        return viewcustomer_schema.dump(Cust)
        # return customers_schema.dump(cust)
class AddCustomer(Resource):
    def get(self):
        cust = Customer.query.all()
        return customers_schema.dump(cust)
    def post(self):
        result = db.execute("SELECT * from Customer WHERE USERNAME = :c", {"c": request.json['username']}).fetchone()
        if result is None :
                # result = db.query(Customer).count()
                new_cust = Customer(
                    CUSTOMER_NAME = request.json['customername'],
                    USERNAME = request.json['username'],
                    PASSWORD = request.json['password'],
                    COMMUNICATION_ADDRESS = request.json['communication_address'],
                    PERMANENT_ADDRESS = request.json['permanent_address'],
                    COUNTRY = request.json['country'],
                    EMAIL_ADDRESS = request.json['email_address'],
                    PAN = request.json['pan'],
                    CONTACT_NO = request.json['contact_no'],
                    DOB = request.json['dob'],
                    ACCOUNT_TYPE = request.json['account_type']
                )
                AppDB.session.add(new_cust)
                AppDB.session.commit()
                return customer_schema.dump(new_cust), 201
        return f"User {request.json['username']} already Exists in the Table."
api.add_resource(AddCustomer,'/addcustomer')
api.add_resource(ViewCustomer,'/viewcustomer/<int:custid>')
api.add_resource(UpdateAccountDetails,'/updatecustomer/<int:custid>')