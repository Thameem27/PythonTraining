from flask import Flask, request, jsonify
from flask_restful import Api, Resource
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import create_engine, exc
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import scoped_session, sessionmaker
from flask_marshmallow import Marshmallow
from marshmallow_sqlalchemy import SQLAlchemySchema, auto_field
Base = declarative_base()
app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///BankDB.sqlite3'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
api = Api(app)
BankDB = SQLAlchemy(app)
ma = Marshmallow(app)
# Set up database
engine = create_engine('sqlite:///BankDB.sqlite3',connect_args={'check_same_thread': False},echo=True)
Base.metadata.bind = engine
db = scoped_session(sessionmaker(bind=engine))
class Loan(BankDB.Model):
    loan_id = BankDB.Column(BankDB.Integer, primary_key=True)
    customer_id = BankDB.Column(BankDB.Integer, unique=True)
    name = BankDB.Column(BankDB.String(10), nullable=False)
    loan_type = BankDB.Column(BankDB.String(30), nullable=False)
    loan_amount= BankDB.Column(BankDB.Integer, nullable=False)
    loan_date = BankDB.Column(BankDB.String(20), nullable=False)
    rate_of_interest = BankDB.Column(BankDB.Integer, nullable=False)
    duration = BankDB.Column(BankDB.Integer, nullable=False)
    def __repr__(self):
        return '<Loan account %r is now created with an loan Type %r >' % (self.loan_id, self.loan_type)
class Customer(BankDB.Model):
    cust_id = BankDB.Column(BankDB.Integer, primary_key=True)
    name = BankDB.Column(BankDB.String(10), nullable=False)
    username = BankDB.Column(BankDB.String(30), nullable=False)
    password = BankDB.Column(BankDB.String(20), nullable=False)
    address = BankDB.Column(BankDB.String(100), nullable=False)
    state = BankDB.Column(BankDB.String(20), nullable=False)
    country = BankDB.Column(BankDB.String(20), nullable=False)
    email_address = BankDB.Column(BankDB.String(50), nullable=False)
    pan = BankDB.Column(BankDB.String(20), nullable=False)
    contact_no= BankDB.Column(BankDB.Integer, nullable=False)
    dob = BankDB.Column(BankDB.String(20), nullable=False)
    account_type = BankDB.Column(BankDB.String(20), nullable=False)
    def __repr__(self):
        return '<User %r is now Created with an Account Type %r >' % (self.username, self.account_type)
class CustomerSchema(ma.SQLAlchemyAutoSchema):
    class Meta:
        model = Customer
class LoanSchema(ma.SQLAlchemyAutoSchema):
    class Meta:
        model = Loan
class ViewCustomerSchema(ma.SQLAlchemySchema):
    class Meta:
        model = Customer
    username=auto_field()
    address=auto_field()
    pan=auto_field()
    account_type=auto_field()
class ViewLoanSchema(ma.SQLAlchemySchema):
    class Meta:
        model = Loan		
    customer_id=auto_field()
    name=auto_field()
    loan_id=auto_field()
    loan_amount=auto_field()
    loan_type=auto_field()
customer_schema = CustomerSchema()
viewcustomer_schema = ViewCustomerSchema()
viewloan_schema = ViewLoanSchema()
customers_schema = CustomerSchema(many=True)
loan_schema = LoanSchema()
loans_schema = LoanSchema(many=True)
class UpdateAccountDetails(Resource):  
    def put(self, customer_id):
        cust = Customer.query.get_or_404(customer_id)
        if 'name' in request.json:
            cust.name = request.json['name']
        if 'username' in request.json:
            cust.username = request.json['username']
        if 'password' in request.json:
           cust.password = request.json['password']
        if 'address' in request.json:
           cust.address = request.json['address']
        if 'state' in request.json:
           cust.state = request.json['state']
        if 'country' in request.json:
           cust.country = request.json['country']
        if 'email_address' in request.json:
           cust.email_address = request.json['email_address']   
        if 'pan' in request.json:
           cust.pan = request.json['pan']
        if 'contact_no' in request.json:
           cust.contact_no = request.json['contact_no']
        if 'dob' in request.json:
           cust.dob = request.json['dob']
        if 'account_type' in request.json:
           cust.account_type = request.json['account_type']         
        BankDB.session.commit()
        return customer_schema.dump(cust)
    def delete(self, customer_id):
        cust = Customer.query.get_or_404(customer_id)
        BankDB.session.delete(cust)
        BankDB.session.commit()
        return '', 204
class ViewCustomer(Resource):
    def get(self,customername):
        Cust = Customer.query.filter_by(username=customername).first_or_404(description='No Customer Exists with this Username {}. Kindly Re-check'.format(customername))
        return viewcustomer_schema.dump(Cust)
        # return customers_schema.dump(cust)
class AddCustomer(Resource):
    def get(self):
        cust = Customer.query.all()
        return customers_schema.dump(cust)
    def post(self):
        result = db.execute("SELECT * from Customer WHERE username = :c", {"c": request.json['username']}).fetchone()
        if result is None :
                # result = db.query(Customer).count()
                new_cust = Customer(
                    name = request.json['name'],
                    username = request.json['username'],
                    password = request.json['password'],
                    address = request.json['address'],
                    state = request.json['state'],
                    country = request.json['country'],
                    email_address = request.json['email_address'],
                    pan = request.json['pan'],
                    contact_no = request.json['contact_no'],
                    dob = request.json['dob'],
                    account_type = request.json['account_type']
                )
                BankDB.session.add(new_cust)
                BankDB.session.commit()
                return customer_schema.dump(new_cust), 201
        return f"User {request.json['username']} already Exists in the Table."
class ApplyLoan(Resource):
    def get(self):
        loan = Loan.query.all()
        return loans_schema.dump(loan)
    def post(self):
        result = db.execute("SELECT * from Loan WHERE name = :c", {"c": request.json['name']}).fetchone()
        if result is None :
                # result = db.query(Customer).count()
                new_loan = Loan(
                    customer_id = request.json['customer_id'],
                    name = request.json['name'],
                    loan_type = request.json['loan_type'],
                    loan_amount = request.json['loan_amount'],
                    loan_date = request.json['loan_date'],
                    rate_of_interest = request.json['rate_of_interest'],
                    duration = request.json['duration']
                )
                BankDB.session.add(new_loan)
                BankDB.session.commit()
                return loan_schema.dump(new_loan), 201
        return f"User {request.json['loan_id']} already exists in the table."
class ViewLoan(Resource):
    def get(self,loan_id):
       loan = Loan.query.filter_by(loan_id=loan_id).first_or_404(description='No loan Exists with this loan Id {}. Kindly Re-check'.format(loan_id))
       return viewloan_schema.dump(loan)
        # return customers_schema.dump(cust)        
api.add_resource(AddCustomer,'/addcustomer')
api.add_resource(ViewCustomer,'/viewcustomer/<customername>')
api.add_resource(UpdateAccountDetails,'/updateaccount/<int:customer_id>')    
api.add_resource(ApplyLoan,'/ApplyLoan')
api.add_resource(ViewLoan,'/GetLoanDetail/<int:loan_id>')